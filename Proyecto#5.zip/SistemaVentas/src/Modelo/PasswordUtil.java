/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class PasswordUtil {

    private static final int ITERACIONES = 600000;
    private static final int LONGITUD_SALT = 16;
    private static final int LONGITUD_HASH = 256;

    public static String hashPassword(String password) {

        try {

            byte[] salt = new byte[LONGITUD_SALT];
            SecureRandom random = new SecureRandom();
            random.nextBytes(salt);

            KeySpec spec = new PBEKeySpec(
                    password.toCharArray(),
                    salt,
                    ITERACIONES,
                    LONGITUD_HASH
            );

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hash = factory.generateSecret(spec).getEncoded();

            return "PBKDF2$"
                    + ITERACIONES
                    + "$"
                    + Base64.getEncoder().encodeToString(salt)
                    + "$"
                    + Base64.getEncoder().encodeToString(hash);

        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("Error al generar el hash de la contraseña", e);
        }
    }

    public static boolean verificarPassword(String password, String passwordHash) {

        try {

            if (passwordHash == null || !passwordHash.startsWith("PBKDF2$")) {
                return false;
            }

            String[] partes = passwordHash.split("\\$");

            if (partes.length != 4) {
                return false;
            }

            int iteraciones = Integer.parseInt(partes[1]);

            byte[] salt = Base64.getDecoder().decode(partes[2]);
            byte[] hashOriginal = Base64.getDecoder().decode(partes[3]);

            KeySpec spec = new PBEKeySpec(
                    password.toCharArray(),
                    salt,
                    iteraciones,
                    hashOriginal.length * 8
            );

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hashNuevo = factory.generateSecret(spec).getEncoded();

            return java.security.MessageDigest.isEqual(
                    hashOriginal,
                    hashNuevo
            );

        } catch (Exception e) {
            return false;
        }
    }
}