/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

public class MigrarContrasena {

    public static void main(String[] args) {

        String contraseña = "12345";

        String hash = PasswordUtil.hashPassword(contraseña);

        System.out.println("Hash generado:");
        System.out.println(hash);
    }
}